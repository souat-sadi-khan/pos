<?php

namespace App\Models\Products;

use Illuminate\Database\Eloquent\Model;

class ProductPicture extends Model
{
    //
}
