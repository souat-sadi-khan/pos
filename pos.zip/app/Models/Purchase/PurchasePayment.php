<?php

namespace App\Models\Purchase;

use Illuminate\Database\Eloquent\Model;

class PurchasePayment extends Model
{
    //
}
