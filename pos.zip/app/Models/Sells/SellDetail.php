<?php

namespace App\Models\Sells;

use Illuminate\Database\Eloquent\Model;

class SellDetail extends Model
{
    //
}
