<div class="">
    <input type="checkbox" class="form-control delete" data-id="{{$model->id}}">
</div>