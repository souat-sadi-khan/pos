<ul class="customer-list list-unstyled">
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li ng-repeat="customers in customerArray" class="ng-scope">
            <a class="select_customer" data-id="<?php echo e($item->id); ?>" href="#"><span class="fa fa-fw fa-user"></span><?php echo e($item->customer_name); ?> (<?php echo e($item->customer_mobile); ?>)
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/sell/sell/show_customer_list.blade.php ENDPATH**/ ?>