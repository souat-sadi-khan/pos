<?php if($model->status == 1): ?>
    <button type="button" class="btn btn-success btn-sm"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
<?php else: ?> 
    <button type="button" class="btn btn-default btn-sm" disabled data-toggle="tooltip" data-placement="top" title="Supplier is InActive . Please Make Active"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
<?php endif; ?><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/supplier/purchase.blade.php ENDPATH**/ ?>