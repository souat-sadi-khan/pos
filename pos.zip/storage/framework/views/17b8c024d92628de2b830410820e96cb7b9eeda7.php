<tr style="font-size: 12px;" id="table_row_<?php echo e($row); ?>">
    
    <td width="30%" class="text-center">
        <?php echo e(substr($product->product_name, 0, 15) . ''. (strlen($product->product_name) > 15 ? '...' : '')); ?>(<?php echo e($product->product_code); ?> )
        
        <input type="hidden" name="product_id[]" class="product_id" value="<?php echo e($product->id); ?>">
        <input type="hidden" name="product_variations_id[]" class="product_variations_id" value="<?php echo e($model->id); ?>">
    
    </td>

    
    <td width="20%">
        <input type="text" class="form-control qty update_qty_<?php echo e($model->id); ?>" data-id="<?php echo e($row); ?>" name="qty[]" id="qty_<?php echo e($row); ?>" placeholder="Etner Quantity" value="1">
    </td>

    
    <td width="20%" class="text-right">
        <input type="text" class="sell_price form-control" value="<?php echo e($model->product_price_inc_tax); ?>">
    </td>

    <td width="30%" class="text-right">
        <span id="net_total">
            <input type="text" class="form-control input-sm net_total" name="net_total[]" id="net_total_<?php echo e($row); ?>">
        </span>
    </td>

    <td class="text-center">
        <i style="cursor: pointer;" class="fa fa-1x fa-times text-danger delete_row" data-id="<?php echo e($row); ?>" aria-hidden="true"></i>
    </td>
</tr>

<script>
    $(function() {
        var qty = 1;
        var price = '<?php echo e($model->product_price_inc_tax); ?>';
        var total = qty * parseInt(price);
        $('#net_total_<?php echo e($row); ?>').val(total);
    })
</script><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/sell/sell/add_sell_row.blade.php ENDPATH**/ ?>