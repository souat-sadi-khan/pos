
<button title="View <?php echo e($model->what_for); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.expense.expense.show',$model->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye"></i></button>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category.update')): ?>
    <button id="content_managment" data-url="<?php echo e(route('admin.expense.expense.edit',$model->id)); ?>" title="Edit <?php echo e($model->what_for); ?>" class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.expense.expense.destroy',$model->id)); ?>" title="Delete <?php echo e($model->what_for); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/expense/expense/action.blade.php ENDPATH**/ ?>