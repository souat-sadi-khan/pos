<div class="row">
    <?php if(count($products) > 0): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('admin.sell.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?> 
        <h2>No Product Found</h2>
    <?php endif; ?>
</div><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/sell/sell/show_product_category_wise.blade.php ENDPATH**/ ?>