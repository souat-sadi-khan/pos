<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.sell')): ?>
    <button title="Sell on <?php echo e($model->customer_name); ?>" class="btn btn-success btn-sm" type="button" disabled><i class="fa fa-cart-plus" aria-hidden="true"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.show')): ?>
    <a title="View <?php echo e($model->customer_name); ?> Information" href="<?php echo e(route('admin.customer.show',$model->id)); ?>"><button class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></button></a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.update')): ?>
    <button title="Update <?php echo e($model->customer_name); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.customer.edit',$model->id)); ?>"  class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.delete')): ?>
    <button title="Delete <?php echo e($model->customer_name); ?>" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.customer.destroy',$model->id)); ?>"  class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/customer/action.blade.php ENDPATH**/ ?>