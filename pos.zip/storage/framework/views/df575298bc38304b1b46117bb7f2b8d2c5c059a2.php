<div class="col-md-6 mx-auto text-center border bg-light border-info">
    <b>Full View Expense Information for : <?php echo e($model->ref_no); ?></b>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-condensed">
        <tbody>
            <tr>
                <td class="w-30">
                    Ref. No.						
                </td>
                <td class="w-70">
                   <?php echo e($model->ref_no); ?>				
                </td>
            </tr>
            <tr>
                <td class="w-30">
                    Created At						
                </td>
                <td class="w-70">
                    <?php echo e(formatDate($model->created_at)); ?>				
                </td>
            </tr>
            <tr>
                <td class="w-30">
                    What For						
                </td>
                <td class="w-70">
                    <?php echo e($model->what_for); ?>

                </td>
            </tr>
            <tr>
                <td class="w-30">
                    Notes						
                </td>
                <td class="w-70">
                    <?php echo e($model->notes); ?>                            
                </td>
            </tr>
            <tr>
                <td class="w-30">
                    Amount						
                </td>
                <td class="w-70">
                    <?php echo e(get_option('currency_symbol')); ?>	<?php echo e(number_format($model->amount, 2)); ?>				
                </td>
            </tr>
            
        </tbody>
    </table>
    </div><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/expense/expense/show.blade.php ENDPATH**/ ?>