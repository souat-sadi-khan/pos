<tr id="table_row_<?php echo e($row); ?>">
    <td width="25%">
        <?php
            $color_query = App\Models\Products\Color::where('status', 1)->select('id', 'color_name')->get();
        ?>
        
        <select data-parsley-errors-container="#select_color_error_<?php echo e($row); ?>" name="color[]" class="form-control select" data-placeholder="Select Color" required>
            <option value="">Select Color</option>
            <option value="0">No Color</option>
            <?php $__currentLoopData = $color_query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->color_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span id="select_color_error_<?php echo e($row); ?>"></span>
    </td>
    <td width="25%">
        <?php
            $size_query = App\Models\Products\Size::where('status', 1)->select('id', 'size_name')->get();
        ?>
        
        <select data-parsley-errors-container="#select_size_error_<?php echo e($row); ?>" name="size[]" class="form-control select" data-placeholder="Select Size" required>
            <option value="">Select Size</option>
            <option value="0">No Size</option>
            <?php $__currentLoopData = $size_query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->size_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span id="select_size_error_<?php echo e($row); ?>"></span>
    </td>
    <td width="20%">
        <input required type="number" name="product_cost[]"  class="form-control" placeholder="Enter Product Cost"/>
    </td>
    <td width="20%">
        <input required type="number" name="product_price[]"  class="form-control" placeholder="Enter Product Price"/>
    </td>
    <td width="25%">
        <i style="cursor: pointer;" class="fa fa-1x fa-times text-danger delete_row" data-id="<?php echo e($row); ?>" aria-hidden="true"></i>
    </td>
</tr><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/product/product/variation/add_one_more_row.blade.php ENDPATH**/ ?>