<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category.update')): ?>
    <button id="content_managment" data-url="<?php echo e(route('admin.expense.expense-category.edit',$model->id)); ?>" title="Edit <?php echo e($model->name); ?>" class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.expense.expense-category.destroy',$model->id)); ?>" title="Delete <?php echo e($model->name); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/expense/category/action.blade.php ENDPATH**/ ?>