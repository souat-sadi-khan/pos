
<?php if($model->purchase_due_amount != 0): ?>
    <button title="Pay <?php echo e($model->invoice); ?>" id="content_managment" data-url="<?php echo e(route('admin.purchase.pay',$model->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-money"></i></button>
<?php endif; ?> 


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.return')): ?>
    <button title="Return <?php echo e($model->invoice); ?>" id="content_managment" data-url="<?php echo e(route('admin.purchase.return',$model->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-minus-circle"></i></button>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.purchase.destroy',$model->id)); ?>" title="Delete <?php echo e($model->invoice); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/purchase/purchase/action.blade.php ENDPATH**/ ?>