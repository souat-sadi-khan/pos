
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
    <a href="<?php echo e(route('admin.products.products.show', $model->id)); ?>"><button title="View <?php echo e($model->product_name); ?> Information" class="btn btn-sm btn-info"><i class="fa fa-eye"></i></button></a>
<?php endif; ?> 





<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.purchase')): ?>
    <a href="<?php echo e(route('admin.product_purchase', $model->id)); ?>"><button title="Purchase <?php echo e($model->product_name); ?>" class="btn btn-sm btn-success"><i class="fa fa-shopping-cart"></i></button></a>
<?php endif; ?> 





<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.products.products.destroy',$model->id)); ?>" title="Delete <?php echo e($model->product_name); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/product/product/action.blade.php ENDPATH**/ ?>