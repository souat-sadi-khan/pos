<nav class="main-header navbar navbar-expand navbar-white navbar-light text-sm py-1">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <?php if(Request::is('admin/point-of-sell')): ?>
            <li class="nav-item">
                <a class="nav-link" ><i class="fa fa-arrow-circle-o-left"></i></a>
            </li>
        <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fa fa-bars"></i></a>
            </li>
        <?php endif; ?>

        <li class="nav-item">
            <a class="nav-link" href="#" role="button"><span id="timestamp"></span>
                </a>
        </li>
        
        
    </ul>

    <!-- SEARCH FORM -->
    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Messages Dropdown Menu -->
        
        <!-- Notifications Dropdown Menu -->
        
        <!-- User Account: style can be found in dropdown.less -->
        <li class="nav-item">
            <a class="nav-link" style="cursor: pointer;" id="content_managment" data-url="<?php echo e(route('admin.contact')); ?> ">
                <i class="fa fa-shopping-bag fa-2" aria-hidden="true"></i>
            </a>
        </li>
        <li class="dropdown nav-item user user-menu">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <img src="<?php echo e((Auth::user()->image != 'user.png' ? asset('storage/images/user'. '/'. Auth::user()->image) : asset('images/user.png'))); ?>" class="user-image" alt="User Image">
                <span class="hidden-xs"><?php echo e(substr(Auth::user()->name, 0 , 15)); ?></span>
            </a>
            <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">
                    <img src="<?php echo e((Auth::user()->image != 'user.png' ? asset('storage/images/user'. '/'. Auth::user()->image) : asset('images/user.png'))); ?>" class="img-circle" alt="User Image">

                    <p>
                        <?php
                            $user_id = Auth::user()->id;
                            $user = App\User::where('id', $user_id)->with('info')->first();
                        ?>
                        <?php echo e(Auth::user()->name); ?> - <?php echo e($user->info->designation); ?>

                        <small>Member since <?php echo e(formatDate(Auth::user()->created_at)); ?></small>
                    </p>
                </li>
                
                <!-- Menu Footer-->
                <li class="user-footer">
                    <div class="pull-left">
                        <a href="<?php echo e(route('admin.me')); ?>" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                        <a id="logout" data-url='<?php echo e(route('logout')); ?>' class="btn btn-default btn-flat">Sign out</a>
                    </div>
                </li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link" style="cursor: pointer;" id="content_managment" data-url="<?php echo e(route('admin.contact')); ?> ">
                <i class="fa fa-question-circle fa-2" aria-hidden="true"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fa fa-th-large"></i>
            </a>
        </li>
    </ul>
</nav><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/_partials/admin/navbar.blade.php ENDPATH**/ ?>