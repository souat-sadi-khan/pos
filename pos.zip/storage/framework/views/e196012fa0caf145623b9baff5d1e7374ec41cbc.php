<?php
    $payable = $model->payable;
    $due = $model->due;
    $paid = $payable - $due;
?>
<h4>Details</h4>
<div class="table-responsive" style="font-size: 12px;">
    <table class="table table-bordered table-striped">
        <tr>
            <td class="text-right" width="30%">Ref. No.</td>
            <td><?php echo e($model->ref_no); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Date Time</td>
            <td><?php echo e(formatDate($model->date)); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Created By</td>
            <td><?php echo e($model->admin->name); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Loan From</td>
            <td><?php echo e($model->loan_from); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Title</td>
            <td><?php echo e($model->title); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Details</td>
            <td><?php echo e($model->details); ?></td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Attachment</td>
            <td>
                <?php if($model->attachment != ''): ?>
                    <img src="<?php echo e(asset('storage/file/loan') . '/'. $model->attatchment); ?>" width="250px" alt="Loan Attatchment">
                <?php endif; ?>
            </td>
        </tr>
        <tr class="table-secondary">
            <td class="text-right" width="30%">Basic Amount	</td>
            <td><?php echo e(get_option('currency_symbol'). ' '. number_format($model->amount, 2)); ?></td>
        </tr>
        <tr class="table-secondary">
            <td class="text-right" width="30%">Interest(%)</td>
            <td><?php echo e(number_format($model->interest, 2)); ?>%</td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Payable Amount</td>
            <td class="table-info">
                <?php echo e(get_option('currency_symbol'). ' '. number_format($model->payable, 2)); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Paid Amount</td>
            <td class="table-success">
                <?php echo e(get_option('currency_symbol'). ' '. number_format($paid, 2)); ?>    
            </td>
        </tr>
        <tr>
            <td class="text-right" width="30%">Due Amount</td>
            <td class="table-danger">
                <?php echo e(get_option('currency_symbol'). ' '. number_format($model->due, 2)); ?>

            </td>
        </tr>
    </table>
</div>

<h6>Payments</h6>
<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead class="table-primary text-white">
            <tr>
                <th>Ref. No.</th>
                <th>Date Time</th>
                <th>Notes</th>
                <th>Paid By	</th>
                <th class="text-right">Paid Amount </th>
            </tr>
        </thead>
        <tbody>
            <?php
                $query = App\Models\LoanPayment::where('loan_id', $model->id)->get();
            ?>
            <?php if(count($query)): ?>
                <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-success">
                        <td><?php echo e($item->ref_no); ?> </td>
                        <td><?php echo e(formatDate($item->created_at)); ?></td>
                        <td><?php echo e($item->note); ?> </td>
                        <td><?php echo e($item->admin->name); ?> </td>
                        <td class="text-right">
                            <?php echo e(get_option('currency_symbol'). ' '. number_format($item->paid, 2)); ?>    
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <tr class="table-secondary">
                    <td colspan="5">No Data Available</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="col-md-12 text-center">
    <button type="button" class="btn btn-primary"> <i class="fa fa-print" aria-hidden="true"></i> &nbsp;Print</button>
</div><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/loan/show.blade.php ENDPATH**/ ?>