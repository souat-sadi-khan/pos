
<?php if($model->due != 0): ?>
    <button title="Pay <?php echo e($model->title); ?>" id="content_managment" data-url="<?php echo e(route('admin.loan.pay',$model->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-money"></i></button>
<?php endif; ?> 

<button title="View <?php echo e($model->title); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.loan.show',$model->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye"></i></button>


<button title="Update <?php echo e($model->title); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.loan.edit',$model->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-pencil-square-o"></i></button>


<button title="Delete <?php echo e($model->title); ?>" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.loan.destroy',$model->id)); ?>" class="btn btn-danger btn-sm delete_<?php echo e($model->id); ?>" disabled><i class="fa fa-trash"></i></button>

    <input type="checkbox" class="check form-control" data-id="<?php echo e($model->id); ?>" multiple="multiple" value="">

<script>
    $(function() {
        $(document).on('click', '.check', function() {
            if(this.checked) {
                var id = $(this).data('id');
                $('.delete_'+id).removeAttr('disabled');
            } else {
                $('.delete_'+id).attr('disabled');
            }
        });

    })
</script><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/loan/action.blade.php ENDPATH**/ ?>