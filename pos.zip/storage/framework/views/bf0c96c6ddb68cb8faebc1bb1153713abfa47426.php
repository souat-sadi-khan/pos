<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.purchase')): ?>
    <?php if($model->status == 1): ?>
        <button title="Purchase From <?php echo e($model->sup_name); ?>" type="button" class="btn btn-success btn-sm"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
    <?php else: ?> 
        <button type="button" class="btn btn-default btn-sm" disabled data-toggle="tooltip" data-placement="top" title="Supplier is InActive . Please Make Active"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
    <?php endif; ?>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.view')): ?>
    <a title="View <?php echo e($model->sup_name); ?> Information" href="<?php echo e(route('admin.supplier.show',$model->id)); ?>"><button class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></button></a>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.update')): ?>
    <button id="content_managment" data-url="<?php echo e(route('admin.supplier.edit',$model->id)); ?>"  class="btn btn-sm btn-info" title="Edit <?php echo e($model->sup_name); ?> Information" ><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.supplier.destroy',$model->id)); ?>" title="Delete <?php echo e($model->sup_name); ?>"  class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?> <?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/supplier/action.blade.php ENDPATH**/ ?>