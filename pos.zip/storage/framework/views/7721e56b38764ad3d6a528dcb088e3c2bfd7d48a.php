<!-- jQuery -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('assets/js/theme.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<!-- Date Dropper -->
<script src="<?php echo e(asset('assets/js/datedropper.min.js')); ?>"></script>
<!-- Select 2 -->
<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
<!-- Main Js -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<!-- parsley js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/parsley.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('install/js/growl.min.js')); ?>"></script>
<!-- Drophify -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/drophify.min.js')); ?>"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function notify(message, type){
        $.growl({
            message: message
        },{
            type: type,
            allow_dismiss: true,
            label: 'Cancel',
            className: 'btn-xs btn-inverse',
            placement: {
                from: "top",
                align: "right"
            },
            delay: 5000,
            animate: {
                    enter: 'animated fadeInRight',
                    exit: 'animated fadeOutRight'
            },
            offset: {
                x: 30,
                y: 30
            }
        });
    };

    $(document).ready(function() {
        setInterval(timestamp, 1000);
    });

    function timestamp() {
        var time = '<?php echo e(formatDate(date('Y-m-d h:i:s'))); ?>';
        $('#timestamp').html(time);
    }
</script>
<?php echo $__env->yieldPushContent('admin.scripts'); ?><?php /**PATH C:\Users\USER\Documents\Work\AdminLte\resources\views/_partials/admin/scripts.blade.php ENDPATH**/ ?>