
<?php
    $query = App\ProductVariation::where('product_id', $product->id)->get();
?>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Product -->
    <div class="col-md-3 text-center">
        <!-- Product Card -->
        <div data-url="<?php echo e(route('admin.add_sell_row')); ?>" data-product_id="<?php echo e($product->id); ?>" data-id="<?php echo e($item->id); ?>" style="cursor: pointer;" class="card add-row">
            <!-- Product Image Start -->
            <img class="card-img-top" src="<?php echo e($product->product_image == '' ? asset('images/product.jpg') : asset('storage/images/product/product'. '/'. $product->product_image)); ?>" height="100px;" alt="Product image">
            <!-- Product Image End -->

            <div class="card-body px-2">
                <p class="card-text text-center " style="min-height: 75px;line-height: 18px;">
                    <!-- Product Name -->
                    <b><?php echo e(substr($product->product_name, 0, 15) . ''. (strlen($product->product_name) > 20 ? '...' : '')); ?>(<?php echo e($product->product_code); ?>)</b> <br>
                    <!-- Product Name -->

                    <!-- Product Size Start -->
                    <?php if($item->size_id != ''): ?>
                        Size : <?php echo e($item->size->size_name); ?> <br>
                    <?php else: ?> 
                        Size : N/A <br>
                    <?php endif; ?>
                    <!-- Product Size End -->

                    <!-- Product Color Start -->
                    <?php if($item->color_id != ''): ?>
                        Color : <?php echo e($item->color->color_name); ?> <br>
                    <?php else: ?> 
                        Color : N/A  <br>
                    <?php endif; ?>
                    <!-- Product Color End -->
                    <br>

                    <!-- Product Product Price -->
                    <b>Price : <?php echo e(get_option('currency_symbol')); ?><?php echo e($item->product_price_inc_tax); ?> </b>

                </p>
            </div>
        </div>
    </div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/sell/product.blade.php ENDPATH**/ ?>