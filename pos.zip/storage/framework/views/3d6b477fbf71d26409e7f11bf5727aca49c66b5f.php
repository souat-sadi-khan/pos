<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> <?php echo e(get_option('site_title') && get_option('site_title') != '' ? get_option('site_title') : 'Sadik'); ?> | Log in</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awosome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('auth/css/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('auth/css/theme.min.css')); ?>">
    <!-- Parslay.min.css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/parsley.css')); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="<?php echo e(route('index')); ?>"><b><?php echo e(get_option('site_title') && get_option('site_title') != '' ? get_option('site_title') : 'Sadik'); ?></b></a>
        </div>
  
        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <!-- Popper js -->
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?> "></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('auth/js/theme.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/parsley.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('install/js/growl.min.js')); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function notify(message, type){
            $.growl({
                message: message
            },{
                type: type,
                allow_dismiss: true,
                label: 'Cancel',
                className: 'btn-xs btn-inverse',
                placement: {
                    from: "top",
                    align: "right"
                },
                delay: 5000,
                animate: {
                        enter: 'animated fadeInRight',
                        exit: 'animated fadeOutRight'
                },
                offset: {
                    x: 30,
                    y: 30
                }
            });
        };
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\Users\USER\Documents\Work\AdminLte\resources\views/layouts/auth.blade.php ENDPATH**/ ?>