<form action="<?php echo e(route('admin.product.box.update', $model->id)); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <div class="row">

        
        <div class="col-md-4 form-group">
            <label for="box_name">Product Box Name <span class="text-danger">*</span></label>
            <input type="text" name="box_name" id="box_name" class="form-control" placeholder="Enter Product Box Name" required value="<?php echo e($model->box_name); ?>">
        </div>

        
        <div class="col-md-4 form-group">
            <label for="box_code_name">Product Box Code </label>
            <input type="text" name="box_code_name" id="box_code_name" class="form-control" placeholder="Enter Product Box Code Name" value="<?php echo e($model->box_code_name); ?>">
        </div>

        
        <div class="col-md-4 form-group">
            <label for="status">Status <span class="text-danger">*</span></label>
            <select data-parsley-errors-container="#status_error" required name="status" id="edit_status" class="form-control select" data-placeholder="Select Status">
                <option value="">Select Status</option>
                <option <?php echo e($model->status == 1 ? 'selected' : ''); ?> value="1">Active</option>
                <option <?php echo e($model->status == 0 ? 'selected' : ''); ?> value="0">Inactive</option>
            </select>
            <span id="status_error"></span>
        </div>

        
        <div class="col-md-12 form-group">
            <label for="box_details">Box Details</label>
            <textarea name="box_details" id="box_details" class="form-control" cols="30" rows="2" placeholder="Enter Box Description"><?php echo e($model->box_details); ?></textarea>
        </div>
    </div>
    <button type="submit" id="edit_submit" class="btn btn-primary float-right px-5"><i class="fa fa-floppy-o mr-3" aria-hidden="true"></i>Save</button>
    <button type="button" id="edit_submiting" class="btn btn-info float-right" id="submiting" style="display: none;"><i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>
    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
</form>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/product/box/edit.blade.php ENDPATH**/ ?>