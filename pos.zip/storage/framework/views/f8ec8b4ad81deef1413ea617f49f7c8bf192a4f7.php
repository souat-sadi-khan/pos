<?php if(Request::is('admin/point-of-sell')): ?>
    
<?php else: ?> 
<aside class="main-sidebar control-sidebar-dark text-sm">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/home')); ?>" class="brand-link">
        <img src="<?php echo e(get_option('logo') && get_option('logo') != '' ? asset('storage/images/logo'). '/'. get_option('logo') : asset('images/logo.png')); ?>"
            alt="Brand Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span
            class="brand-text font-weight-light"><?php echo e(get_option('site_title') && get_option('site_title') != '' ? substr(get_option('site_title'), 0, 10) : 'Sadik'); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e((Auth::user()->image != 'user.png' ? asset('storage/images/user'. '/'. Auth::user()->image) : asset('images/user.png'))); ?>" alt="User Image">
            </div>
            <div class="info">
                <a href="" class="d-block"><?php echo e(Auth::user()->name); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent nav-compact nav-flat" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(url('/home')); ?>" class="nav-link <?php echo e(Request::is('home') ? 'active':''); ?>">
                        <i class="nav-icon fa fa-tachometer"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('admin.point-of-sell')); ?>" class="nav-link <?php echo e(Request::is('admin/point-of-sell') ? 'active':''); ?>">
                        <i class="nav-icon fa fa-sellsy"></i>
                        <p>POINT OF SELL</p>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_initialize.view')): ?>
                    
                    <li class="nav-item has-treeview <?php echo e(Request::is('admin/product-initiazile*') ? 'menu-open' : ''); ?> ">
                        <a href="#" class="nav-link <?php echo e(Request::is('admin/product-initiazile*') ? 'active' : ''); ?> ">
                            <i class="nav-icon fa fa-cog"></i>
                            <p>
                                Product Initialize
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>

                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.category.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/category') ? 'active' : ''); ?>">
                                        <i class="fa fa-cart-plus nav-icon"></i>
                                        <p>Category</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.brand.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/brand') ? 'active' : ''); ?>">
                                        <i class="fa fa-bold nav-icon"></i>
                                        <p>Brand</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('unit.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.unit.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/unit') ? 'active' : ''); ?>">
                                        <i class="fa fa-underline nav-icon"></i>
                                        <p>Unit</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('box.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.box.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/box') ? 'active' : ''); ?>">
                                        <i class="fa fa-archive nav-icon"></i>
                                        <p>Box</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('taxrate.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.taxrate.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/taxrate') ? 'active' : ''); ?>">
                                        <i class="fa fa-usd nav-icon"></i>
                                        <p>TaxRate</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('size.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.size.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/size') ? 'active' : ''); ?>">
                                        <i class="fa fa-scribd nav-icon"></i>
                                        <p>Size</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('color.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.color.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/color') ? 'active' : ''); ?>">
                                        <i class="fa fa-creative-commons nav-icon"></i>
                                        <p>Color</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_method.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.product-initiazile.payment-method.index')); ?> " class="nav-link <?php echo e(Request::is('admin/product-initiazile/payment-method') ? 'active' : ''); ?>">
                                        <i class="fa fa-paypal nav-icon"></i>
                                        <p>Payment Method</p>
                                    </a>
                                </li>
                            <?php endif; ?> 

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_section.view')): ?>
                    
                    <li class="nav-item has-treeview <?php echo e(Request::is('admin/products*') ? 'menu-open' : ''); ?> ">
                        <a href="#" class="nav-link <?php echo e(Request::is('admin/products*') ? 'active' : ''); ?> ">
                            <i class="nav-icon fa fa-star"></i>
                            <p>
                                Products
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>

                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
                                
                                <li class="nav-item">
                                <a href="<?php echo e(route('admin.products.products.index', 'show=list')); ?> " class="nav-link <?php echo e(isset($product_sidebar) && $product_sidebar == 'list' ? 'active' : ''); ?>">
                                        <i class="fa fa-list nav-icon"></i>
                                        <p>Product List</p>
                                    </a>
                                </li>

                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.products.products.index', 'show=create')); ?> " class="nav-link <?php echo e(isset($product_sidebar) && $product_sidebar == 'create' ? 'active' : ''); ?>">
                                        <i class="fa fa-plus-circle nav-icon"></i>
                                        <p>Create Product</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.import')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.products.products.import')); ?> " class="nav-link <?php echo e(Request::is('admin/products/import-products') ? 'active' : ''); ?>">
                                        <i class="fa fa-upload nav-icon"></i>
                                        <p>Import Products</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.import')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.products.stock_alert')); ?> " class="nav-link <?php echo e(Request::is('admin/products/stock-alert') ? 'active' : ''); ?>">
                                        <i class="fa fa-exclamation-triangle nav-icon"></i>
                                        <p>Stock Alert</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                           
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_purchase.view')): ?>
                
                    <li class="nav-item has-treeview <?php echo e(Request::is('admin/purchase*') ? 'menu-open' : ''); ?> ">
                        <a href="#" class="nav-link <?php echo e(Request::is('admin/purchase*') ? 'active' : ''); ?> ">
                            <i class="nav-icon fa fa-shopping-bag"></i>
                            <p>
                                Purchase
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>

                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.view')): ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.purchase.index', 'show=list')); ?> " class="nav-link <?php echo e(isset($purchase_sidebar) && $purchase_sidebar == 'list' ? 'active' : ''); ?>">
                                        <i class="fa fa-list nav-icon"></i>
                                        <p>Purchase List</p>
                                    </a>
                                </li>

                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.purchase.index', 'show=create')); ?> " class="nav-link <?php echo e(isset($purchase_sidebar) && $purchase_sidebar == 'create' ? 'active' : ''); ?>">
                                        <i class="fa fa-plus-circle nav-icon"></i>
                                        <p>Create Purchase</p>
                                    </a>
                                </li>

                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.purchase.due_invoice')); ?> " class="nav-link <?php echo e(Request::is('admin/purchase/due-purchase-invoice') ? 'active':''); ?>">
                                        <i class="fa fa-cc-jcb nav-icon"></i>
                                        <p>Due Invocie</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.view')): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.customer.index')); ?>" class="nav-link <?php echo e(Request::is('admin/customer*') ? 'active':''); ?>">
                            <i class="nav-icon fa fa-user"></i>
                            <p>Customer</p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.view')): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.supplier.index')); ?>" class="nav-link <?php echo e(Request::is('admin/supplier*') ? 'active':''); ?>">
                            <i class="nav-icon fa fa-truck"></i>
                            <p>Supplier</p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounting.view')): ?>
                <li class="nav-item has-treeview <?php echo e(Request::is('admin/account*') ? 'menu-open' : ''); ?> ">
                    <a href="#" class="nav-link <?php echo e(Request::is('admin/account*') ? 'active' : ''); ?> ">
                        <i class="nav-icon fa fa-university"></i>
                        <p>
                            Accounting
                            <i class="right fa fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.account.bank-account.index', 'show=create')); ?> " class="nav-link <?php echo e(isset($bank_account_sidebar) && $bank_account_sidebar == 'create' ? 'active' : ''); ?>">
                                <i class="fa fa-plus nav-icon"></i>
                                <p>Add Bank Account</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.account.bank-account.index', 'show=list')); ?> " class="nav-link <?php echo e(isset($bank_account_sidebar) && $bank_account_sidebar == 'list' ? 'active' : ''); ?>">
                                <i class="fa fa-sign-in nav-icon"></i>
                                <p>Bank Account List</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.account.diposit.index')); ?> " class="nav-link <?php echo e(Request::is('admin/account/diposit') ? 'active' : ''); ?>">
                                <i class="fa fa-plus nav-icon"></i>
                                <p>Diposit</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.dashboard')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/dashboard') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Withdraw</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.login')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/login') ? 'active' : ''); ?>">
                                <i class="fa fa-sign-in nav-icon"></i>
                                <p>Transaction List</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.settings')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/general') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Transfer List</p>
                            </a>
                        </li>
                        

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.settings')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/general') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Income Source</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.dashboard')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/dashboard') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Balance Sheet</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.login')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/login') ? 'active' : ''); ?>">
                                <i class="fa fa-sign-in nav-icon"></i>
                                <p>Income MonthWise</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.settings')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/general') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Expense MonthWise</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.dashboard')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/dashboard') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Income vs Expense</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.login')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/login') ? 'active' : ''); ?>">
                                <i class="fa fa-sign-in nav-icon"></i>
                                <p>Profit vs Loss</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenditure.view')): ?>
                <li class="nav-item has-treeview <?php echo e(Request::is('admin/expense*') ? 'menu-open' : ''); ?> ">
                    <a href="#" class="nav-link <?php echo e(Request::is('admin/expense*') ? 'active' : ''); ?> ">
                        <i class="nav-icon fa fa-minus"></i>
                        <p>
                            Expense
                            <i class="right fa fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.expense.expense.index', 'show=create')); ?> " class="nav-link <?php echo e(isset($expense) && $expense == 'create' ? 'active' : ''); ?>">
                                <i class="fa fa-plus nav-icon"></i>
                                <p>Add Expense</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.expense.expense.index', 'show=list')); ?> " class="nav-link <?php echo e(isset($expense) && $expense == 'list' ? 'active' : ''); ?>">
                                <i class="fa fa-list nav-icon"></i>
                                <p>Expense List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.expense.expense-category.index', 'show=create')); ?> " class="nav-link <?php echo e(isset($expense_category) && $expense_category == 'create' ? 'active' : ''); ?>">
                                <i class="fa fa-plus nav-icon"></i>
                                <p>Add Category</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.expense.expense-category.index', 'show=list')); ?> " class="nav-link <?php echo e(isset($expense_category) && $expense_category == 'list' ? 'active' : ''); ?>">
                                <i class="fa fa-list nav-icon"></i>
                                <p>Category List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.expense.expense_summer')); ?> " class="nav-link <?php echo e(Request::is('admin/expense/expens-summery') ? 'active' : ''); ?>">
                                <i class="fa fa-film nav-icon"></i>
                                <p>Summery</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                
                <li class="nav-item has-treeview <?php echo e(Request::is('admin/loan*') ? 'menu-open' : ''); ?> ">
                    <a href="#" class="nav-link <?php echo e(Request::is('admin/loan*') ? 'active' : ''); ?> ">
                        <i class="nav-icon fa fa-tasks"></i>
                        <p>
                            Loan Manage
                            <i class="right fa fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.loan.index')); ?> " class="nav-link <?php echo e(Request::is('admin/loan') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Loan List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.loan.summery')); ?> " class="nav-link <?php echo e(Request::is('admin/loan/summery') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Summary</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item has-treeview <?php echo e(Request::is('admin/settings*') ? 'menu-open' : ''); ?> ">
                    <a href="#" class="nav-link <?php echo e(Request::is('admin/settings*') ? 'active' : ''); ?> ">
                        <i class="nav-icon fa fa-cog"></i>
                        <p>
                            Settings
                            <i class="right fa fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.settings')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/general') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>General Settings</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.dashboard')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/dashboard') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>Dashboard Settings</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.login')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/login') ? 'active' : ''); ?>">
                                <i class="fa fa-sign-in nav-icon"></i>
                                <p>Login Settings</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>

<?php endif; ?><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/_partials/admin/sidebar.blade.php ENDPATH**/ ?>