<form action="<?php echo e(route('admin.loan.update',$model->id)); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('PATCH'); ?>
    <input type="hidden" name="old_attatchment" value="<?php echo e($model->attatchment); ?>">
    
    <div class="col-md-10 mx-auto form-group">
        <label for="loan_from"><?php echo e(__('Loan From')); ?> <span class="text-danger">*</span></label>
        <select data-parsley-errors-container="#loan_form_error" name="loan_from" id="loan_from" class="form-control select" required data-placeholder="Please Select One">
            <option value=""><?php echo e(__('Please Select One')); ?></option>
            <option <?php echo e($model->loan_from == 'Bank' ? 'selected' : ''); ?> value="Bank"><?php echo e(__('Bank')); ?></option>
            <option <?php echo e($model->loan_from == 'NGO' ? 'selected' : ''); ?> value="NGO"><?php echo e(__('NGO')); ?></option>
            <option <?php echo e($model->loan_from == 'Person' ? 'selected' : ''); ?> value="Person"><?php echo e(__('Person')); ?></option>
            <option <?php echo e($model->loan_from == 'Other' ? 'selected' : ''); ?> value="Other"><?php echo e(__('Other')); ?></option>
        </select>
        <span id="loan_form_error"></span>
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="ref_no"><?php echo e(__('Reference Number')); ?></label>
        <input type="text" name="ref_no" id="ref_no" class="form-control" placeholder="Enter Reference Number" value="<?php echo e($model->ref_no); ?>">
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="title"><?php echo e(__('Title')); ?> <span class="text-danger">*</span></label>
        <input type="text" name="title" id="title" class="form-control" placeholder="Enter Loan Title" required value="<?php echo e($model->title); ?>">
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="amount"><?php echo e(__('Amount')); ?> <span class="text-danger">*</span></label>
        <input required type="number" id="edit_amount" name="amount" class="form-control" placeholder="Enter Loan Amount" value="<?php echo e($model->amount); ?>">
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="interest"><?php echo e(__('Interest')); ?> (%) <span class="text-danger">*</span></label>
        <input required type="number" id="edit_interest" name="interest" class="form-control" placeholder="Enter Interest Percen" value="<?php echo e($model->interest); ?>">
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="payable"><?php echo e(__('Payable')); ?> <span class="text-danger">*</span></label>
        <input type="text" readonly required placeholder="Enter Payable Amount" class="form-control" id="edit_payable" name="payable" value="<?php echo e($model->payable); ?>">
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="details"><?php echo e(__('Details')); ?></label>
        <textarea name="details" id="details" class="form-control" cols="30" rows="2" placeholder="Enter Description"><?php echo e($model->details); ?></textarea>
    </div>

    
    <div class="col-md-10 mx-auto form-group">
        <label for="attatchment"><?php echo e(__('Attatchment')); ?></label>
        <input type="file" name="attatchment" id="attatchment" class="form-control dropify">
    </div>

    <button type="submit" id="submit" class="btn btn-primary btn-sm">Store</button>
    <button type="button" id="submiting" class="btn btn-sm btn-info" id="submiting" style="display: none;">
        <i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>

    <button type="button" class="btn btn-sm btn-danger float-right" data-dismiss="modal">Close</button>
</form>
<script>
    _componentSelect2Normal();
    _componentDropFile();

    $('#edit_interest').keyup(function() {
        interest = parseInt($(this).val());
        amount = parseInt($('#edit_amount').val());
        per = (amount * interest) / 100;
        var result = amount + per;
        $('#edit_payable').val(result);
    });

    $('#edit_amount').keyup(function() {
        amount = parseInt($(this).val());
        interest = parseInt($('#edit_interest').val());
        per = (amount * interest) / 100 ;
        var result = amount + per;
        $('#edit_payable').val(result);
    });
</script><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/loan/edit.blade.php ENDPATH**/ ?>