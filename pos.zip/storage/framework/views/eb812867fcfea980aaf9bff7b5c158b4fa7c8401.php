<div class="">
    <input type="checkbox" class="form-control delete" data-id="<?php echo e($model->id); ?>">
</div><?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/product/product/delete.blade.php ENDPATH**/ ?>