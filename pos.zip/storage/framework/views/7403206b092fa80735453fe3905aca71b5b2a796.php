<div class="col-md-6 mx-auto text-center border mb-3 bg-light border-info">
    <b>Edit Bank Account Information for : <?php echo e($model->account_name); ?></b>
</div>

<form action="<?php echo e(route('admin.account.bank-account.update', $model->id)); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
 
    <div class="row">

        
        <div class="col-md-6 form-group">
            <label for="account_name">Account Name <span class="text-danger">*</span></label>
            <input value="<?php echo e($model->account_name); ?>" type="text" name="account_name" id="edit_account_name" class="form-control" placeholder="Enter Account Name" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="account_no">Account Number <span class="text-danger">*</span></label>
            <input value="<?php echo e($model->account_no); ?>" type="text" name="account_no" id="edit_account_no" class="form-control" placeholder="Enter Account Number" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="phone">Phone <span class="text-danger">*</span></label>
            <input value="<?php echo e($model->phone); ?>" type="text" name="phone" id="edit_phone" class="form-control" placeholder="Enter Phone Number" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="contact_person">Contact Person <span class="text-danger">*</span></label>
            <input value="<?php echo e($model->contact_person); ?>" type="text" name="contact_person" id="edit_contaact_person" class="form-control" placeholder="Enter Contact Person Name" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="account_url">Internet Banking URL</label>
            <input value="<?php echo e($model->account_url); ?>" type="text" name="account_url" id="edit_account_url" class="form-control" placeholder="Enter Internet Banking URL">
        </div>

        
        <div class="col-md-6 form-group">
            <label for="status">Status <span class="text-danger">*</span></label>
            <select name="status" id="edit_status" class="form-control select" data-placeholder="Select Status" data-parsley-errors-container="#edit_status_error">
                <option value="">Select Status</option>
                <option <?php echo e($model->status == 1 ? 'selected' : ''); ?> value="1">Active</option>
                <option <?php echo e($model->status == 1 ? 'selected' : ''); ?> value="0">Inactive</option>
            </select>
            <span id="edit_status_error"></span>
        </div>

        
        <div class="col-md-12 form-group">
            <label for="account_details">Account Details</label>
            <textarea name="account_details" id="edit_account_details" cols="30" rows="2" class="form-control" placeholder="Enter Account Details"><?php echo e($model->account_details); ?></textarea>
        </div>

    </div>

    <button type="submit" id="edit_submit" class="btn btn-primary float-right px-5"><i class="fa fa-floppy-o mr-3" aria-hidden="true"></i>Save</button>
    <button type="button" id="edit_submiting" class="btn btn-info float-right" id="submiting" style="display: none;"><i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>
    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
</form>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/account/bank-account/edit.blade.php ENDPATH**/ ?>