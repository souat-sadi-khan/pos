<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(isset($title) ? $title : ''); ?> | <?php echo e(get_option('site_title') && get_option('site_title') != '' ? get_option('site_title') : 'Sadik'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- StyleSheet -->
    <?php echo $__env->make('_partials.admin.stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="<?php echo e(Request::is('admin/purchase*') ? 'hold-transition  sidebar-collapse' : ''); ?> <?php echo e(Request::is('admin/point-of-sell') ? 'sidebar-collapse' : ''); ?> ">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php echo $__env->make('_partials.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Sidebar Container -->
        <?php echo $__env->make('_partials.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

            <div style="position: absolute;top: 50%;left: 50%;z-index:100; display:none;" id="loader">
                <i class="fa fa-spinner fa-spin fa-5x fa-fw"></i><h3>Loading...</h3>
            </div>
            
            <!-- Content Header (Page header) -->
            <?php echo $__env->yieldContent('header'); ?>

            <!-- Main content -->
            <section class="content">

                <?php echo $__env->yieldContent('content'); ?>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <footer class="main-footer">
            <div class="float-right d-none d-sm-block">
                <b>Version</b> 1.0.0
            </div>
            <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="http://www.sattit.com">Satt IT</a>.</strong> All rights reserved.
        </footer>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php if(isset($modal)): ?>
        <!-- Remote source -->
        <div id="modal_remote" class="modal fade border-top-success rounded-top-0" data-backdrop="static"  role="dialog">
            <div class="modal-dialog modal-<?php echo e($modal); ?> modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-light border-grey-300">
                        <h5 class="modal-title"><?php echo e($title); ?></h5>
                        <button type="button" class="close text-danger" data-dismiss="modal">&times;</button>
                    </div>
                    <div id="modal-loader" style="display: none; text-align: center;">
                        <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span>
                    </div>
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
        <!-- /remote source -->
    <?php endif; ?>

    <?php echo $__env->make('_partials.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/layouts/main.blade.php ENDPATH**/ ?>