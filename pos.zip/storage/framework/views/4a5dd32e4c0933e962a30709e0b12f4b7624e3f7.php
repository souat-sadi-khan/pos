<div class="col-md-6 mx-auto text-center border mb-3 bg-light border-info">
    <b>Full View Bank Account Information for : <?php echo e($model->account_name); ?></b>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <tr>
            <th class="text-center">Account Name</th>
            <th class="text-center"><?php echo e($model->account_name); ?></th>
        </tr>
        <tr>
            <th class="text-center">Account Details</th>
            <th class="text-center"><?php echo e($model->account_details); ?></th>
        </tr>
        <tr>
            <th class="text-center">Account Number</th>
            <th class="text-center"><?php echo e($model->account_no); ?></th>
        </tr>
        <tr>
            <th class="text-center">Contact Person</th>
            <th class="text-center"><?php echo e($model->contact_person); ?></th>
        </tr>
        <tr>
            <th class="text-center">Phone</th>
            <th class="text-center"><?php echo e($model->phone); ?></th>
        </tr>
        <tr>
            <th class="text-center">Internet Banking URL</th>
            <th class="text-center"><?php echo e($model->account_url); ?></th>
        </tr>
        <tr>
            <th class="text-center">Status</th>
            <th class="text-center">
                <?php if($model->status == 1): ?>
                    <span class="badge badge-primary">Active</span>
                <?php else: ?> 
                    <span class="badge badge-warning">Inactive</span>
                <?php endif; ?>    
            </th>
        </tr>
    </table>
</div>
<?php /**PATH C:\Users\USER\Documents\Work\pos\resources\views/admin/account/bank-account/show.blade.php ENDPATH**/ ?>