<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/home')); ?>" class="brand-link">
        <img src="<?php echo e(get_option('logo') && get_option('logo') != '' ? asset('storage/images/logo'). '/'. get_option('logo') : asset('images/logo.png')); ?>"
            alt="Brand Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span
            class="brand-text font-weight-light"><?php echo e(get_option('site_title') && get_option('site_title') != '' ? substr(get_option('site_title'), 0, 10) : 'Sadik'); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('images') .'/'. Auth::user()->image); ?>" alt="User Image">
            </div>
            <div class="info">
                <a href="" class="d-block"><?php echo e(Auth::user()->name); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(url('/home')); ?>" class="nav-link <?php echo e(Request::is('home') ? 'active':''); ?>">
                        <i class="nav-icon fa fa-tachometer"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item has-treeview <?php echo e(Request::is('admin/settings*') ? 'menu-open' : ''); ?> ">
                    <a href="#" class="nav-link <?php echo e(Request::is('admin/settings*') ? 'active' : ''); ?> ">
                        <i class="nav-icon fa fa-cog"></i>
                        <p>
                            Settings
                            <i class="right fa fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.general.settings')); ?> " class="nav-link <?php echo e(Request::is('admin/settings/general') ? 'active' : ''); ?>">
                                <i class="fa fa-stop-circle nav-icon"></i>
                                <p>General Settings</p>
                            </a>
                        </li>
                    </ul>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\Users\USER\Documents\Work\AdminLte\resources\views/_partials/admin/sidebar.blade.php ENDPATH**/ ?>